import React from 'react';
import { motion } from 'framer-motion';
import { 
  Activity, 
  Calendar, 
  Trophy, 
  Target, 
  Clock, 
  Flame,
  TrendingUp,
  Users,
  Play,
  Pause,
  SkipForward
} from 'lucide-react';

const Dashboard = () => {
  const stats = [
    { icon: Flame, value: '1,247', label: 'Calories Burned', change: '+12%' },
    { icon: Clock, value: '45', label: 'Minutes Today', change: '+8%' },
    { icon: Target, value: '78%', label: 'Weekly Goal', change: '+15%' },
    { icon: Trophy, value: '23', label: 'Achievements', change: '+3%' },
  ];

  const workouts = [
    {
      title: 'HIIT Cardio Blast',
      trainer: 'Sarah Johnson',
      duration: '30 min',
      difficulty: 'Intermediate',
      image: 'https://images.pexels.com/photos/3757942/pexels-photo-3757942.jpeg',
      isLive: true
    },
    {
      title: 'Strength Training',
      trainer: 'Mike Chen',
      duration: '45 min',
      difficulty: 'Advanced',
      image: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg',
      isLive: false
    },
    {
      title: 'Yoga Flow',
      trainer: 'Emma Davis',
      duration: '20 min',
      difficulty: 'Beginner',
      image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg',
      isLive: false
    },
  ];

  return (
    <div className="min-h-screen pt-20 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-white mb-2">Welcome back, Alex! 💪</h1>
          <p className="text-gray-400">Ready to crush your fitness goals today?</p>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
        >
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                whileHover={{ scale: 1.05 }}
                className="bg-gradient-to-br from-dark-800/50 to-dark-900/50 backdrop-blur-md border border-white/10 rounded-xl p-6"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-gradient-to-r from-primary-500 to-secondary-500 p-2 rounded-lg">
                    <Icon className="h-5 w-5 text-white" />
                  </div>
                  <span className="text-success-400 text-sm font-medium">{stat.change}</span>
                </div>
                <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-gray-400 text-sm">{stat.label}</div>
              </motion.div>
            );
          })}
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Today's Workout */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2"
          >
            <div className="bg-gradient-to-br from-dark-800/50 to-dark-900/50 backdrop-blur-md border border-white/10 rounded-xl p-6">
              <h2 className="text-xl font-semibold text-white mb-6">Today's Workouts</h2>
              <div className="space-y-4">
                {workouts.map((workout, index) => (
                  <motion.div
                    key={index}
                    whileHover={{ scale: 1.02 }}
                    className="flex items-center space-x-4 p-4 bg-dark-800/50 rounded-lg border border-white/5 hover:border-primary-500/30 transition-all duration-300"
                  >
                    <div className="relative">
                      <img
                        src={workout.image}
                        alt={workout.title}
                        className="w-16 h-16 rounded-lg object-cover"
                      />
                      {workout.isLive && (
                        <div className="absolute -top-1 -right-1 bg-error-500 text-white text-xs px-2 py-1 rounded-full">
                          LIVE
                        </div>
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-white">{workout.title}</h3>
                      <p className="text-gray-400 text-sm">with {workout.trainer}</p>
                      <div className="flex items-center space-x-4 mt-1">
                        <span className="text-gray-500 text-xs flex items-center">
                          <Clock className="h-3 w-3 mr-1" />
                          {workout.duration}
                        </span>
                        <span className="text-gray-500 text-xs">{workout.difficulty}</span>
                      </div>
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className="bg-gradient-to-r from-primary-500 to-secondary-500 p-3 rounded-full hover:shadow-lg transition-all duration-300"
                    >
                      <Play className="h-5 w-5 text-white" />
                    </motion.button>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-6"
          >
            {/* Progress Ring */}
            <div className="bg-gradient-to-br from-dark-800/50 to-dark-900/50 backdrop-blur-md border border-white/10 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Today's Progress</h3>
              <div className="flex items-center justify-center">
                <div className="relative w-32 h-32">
                  <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 36 36">
                    <path
                      d="M18,2.0845 a 15.9155,15.9155 0 0,1 0,31.831 a 15.9155,15.9155 0 0,1 0,-31.831"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeDasharray="78, 100"
                      strokeLinecap="round"
                      className="text-primary-500"
                    />
                    <path
                      d="M18,2.0845 a 15.9155,15.9155 0 0,1 0,31.831 a 15.9155,15.9155 0 0,1 0,-31.831"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeDasharray="100, 100"
                      className="text-dark-700"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white">78%</div>
                      <div className="text-xs text-gray-400">Complete</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-gradient-to-br from-dark-800/50 to-dark-900/50 backdrop-blur-md border border-white/10 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full bg-gradient-to-r from-primary-500 to-secondary-500 text-white py-3 px-4 rounded-lg font-medium transition-all duration-300 hover:shadow-lg"
                >
                  Start Workout
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full bg-white/10 backdrop-blur-md border border-white/20 text-white py-3 px-4 rounded-lg font-medium transition-all duration-300 hover:bg-white/20"
                >
                  Schedule Session
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full bg-white/10 backdrop-blur-md border border-white/20 text-white py-3 px-4 rounded-lg font-medium transition-all duration-300 hover:bg-white/20"
                >
                  View Progress
                </motion.button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;