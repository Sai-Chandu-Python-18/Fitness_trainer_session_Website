import React from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Heart, Share2, Trophy, Users, TrendingUp } from 'lucide-react';

const Community = () => {
  const posts = [
    {
      user: {
        name: 'Sarah Johnson',
        avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
        level: 'Pro Member'
      },
      content: 'Just completed my first 5K run! 🏃‍♀️ Thanks to the amazing community support and training plans. Feeling stronger every day! 💪',
      image: 'https://images.pexels.com/photos/2803158/pexels-photo-2803158.jpeg',
      likes: 42,
      comments: 12,
      timeAgo: '2 hours ago',
      achievement: 'First 5K Complete'
    },
    {
      user: {
        name: 'Mike Chen',
        avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg',
        level: 'Elite Member'
      },
      content: 'Sharing my home gym setup! After 6 months with FitPro, I\'ve built this amazing space. The equipment recommendations were spot on! 🏋️‍♂️',
      image: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg',
      likes: 89,
      comments: 23,
      timeAgo: '4 hours ago',
      achievement: null
    },
    {
      user: {
        name: 'Emma Davis',
        avatar: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg',
        level: 'Pro Member'
      },
      content: 'Morning yoga session complete! ✨ The live sessions with trainer Lisa are absolutely incredible. Feeling so zen and energized for the day ahead! 🧘‍♀️',
      image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg',
      likes: 65,
      comments: 18,
      timeAgo: '1 day ago',
      achievement: '30 Day Streak'
    }
  ];

  const challenges = [
    {
      title: '30-Day Transformation',
      participants: 1247,
      prize: '$500 Gift Card',
      endDate: '15 days left',
      difficulty: 'Intermediate'
    },
    {
      title: 'Summer Shred Challenge',
      participants: 892,
      prize: 'Personal Training Session',
      endDate: '8 days left',
      difficulty: 'Advanced'
    },
    {
      title: 'Mindful Movement',
      participants: 634,
      prize: 'Wellness Retreat',
      endDate: '22 days left',
      difficulty: 'Beginner'
    }
  ];

  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-dark-900 via-dark-800 to-dark-900" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Join Our{' '}
            <span className="bg-gradient-to-r from-primary-400 to-secondary-400 bg-clip-text text-transparent">
              Community
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Connect with thousands of fitness enthusiasts, share your journey, 
            and get motivated by others' success stories.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Community Feed */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-2"
          >
            <div className="bg-gradient-to-br from-dark-800/50 to-dark-900/50 backdrop-blur-md border border-white/10 rounded-xl p-6">
              <h3 className="text-xl font-semibold text-white mb-6">Community Feed</h3>
              <div className="space-y-6">
                {posts.map((post, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-dark-800/50 rounded-xl p-6 border border-white/5"
                  >
                    {/* Post Header */}
                    <div className="flex items-center space-x-3 mb-4">
                      <img
                        src={post.user.avatar}
                        alt={post.user.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <h4 className="font-semibold text-white">{post.user.name}</h4>
                          <span className="text-xs bg-primary-500/20 text-primary-400 px-2 py-1 rounded-full">
                            {post.user.level}
                          </span>
                          {post.achievement && (
                            <span className="text-xs bg-success-500/20 text-success-400 px-2 py-1 rounded-full flex items-center space-x-1">
                              <Trophy className="h-3 w-3" />
                              <span>{post.achievement}</span>
                            </span>
                          )}
                        </div>
                        <p className="text-gray-400 text-sm">{post.timeAgo}</p>
                      </div>
                    </div>

                    {/* Post Content */}
                    <p className="text-gray-300 mb-4 leading-relaxed">{post.content}</p>
                    
                    {/* Post Image */}
                    <div className="mb-4 rounded-lg overflow-hidden">
                      <img
                        src={post.image}
                        alt="Post"
                        className="w-full h-48 object-cover"
                      />
                    </div>

                    {/* Post Actions */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-6">
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className="flex items-center space-x-2 text-gray-400 hover:text-red-400 transition-colors"
                        >
                          <Heart className="h-5 w-5" />
                          <span className="text-sm">{post.likes}</span>
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className="flex items-center space-x-2 text-gray-400 hover:text-blue-400 transition-colors"
                        >
                          <MessageSquare className="h-5 w-5" />
                          <span className="text-sm">{post.comments}</span>
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className="text-gray-400 hover:text-green-400 transition-colors"
                        >
                          <Share2 className="h-5 w-5" />
                        </motion.button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            {/* Community Stats */}
            <div className="bg-gradient-to-br from-dark-800/50 to-dark-900/50 backdrop-blur-md border border-white/10 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Community Stats</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Users className="h-5 w-5 text-primary-400" />
                    <span className="text-gray-300">Active Members</span>
                  </div>
                  <span className="text-white font-semibold">12,847</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5 text-secondary-400" />
                    <span className="text-gray-300">Posts Today</span>
                  </div>
                  <span className="text-white font-semibold">234</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Trophy className="h-5 w-5 text-accent-400" />
                    <span className="text-gray-300">Achievements</span>
                  </div>
                  <span className="text-white font-semibold">1,892</span>
                </div>
              </div>
            </div>

            {/* Active Challenges */}
            <div className="bg-gradient-to-br from-dark-800/50 to-dark-900/50 backdrop-blur-md border border-white/10 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Active Challenges</h3>
              <div className="space-y-4">
                {challenges.map((challenge, index) => (
                  <motion.div
                    key={index}
                    whileHover={{ scale: 1.02 }}
                    className="bg-dark-800/50 rounded-lg p-4 border border-white/5 hover:border-primary-500/30 transition-all duration-300"
                  >
                    <h4 className="font-semibold text-white mb-2">{challenge.title}</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">Participants</span>
                        <span className="text-white">{challenge.participants.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">Prize</span>
                        <span className="text-accent-400">{challenge.prize}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">Ends in</span>
                        <span className="text-error-400">{challenge.endDate}</span>
                      </div>
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="w-full bg-gradient-to-r from-primary-500 to-secondary-500 text-white py-2 px-4 rounded-lg font-medium mt-3 transition-all duration-300 hover:shadow-lg"
                    >
                      Join Challenge
                    </motion.button>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Community;