import React from 'react';
import { motion } from 'framer-motion';
import { Check, Star, Zap, Crown } from 'lucide-react';

const Pricing = () => {
  const plans = [
    {
      name: 'Basic',
      icon: Star,
      price: '$9.99',
      period: '/month',
      description: 'Perfect for fitness beginners',
      features: [
        'Access to basic workout library',
        'Mobile app access',
        'Community forum access',
        'Basic progress tracking',
        'Email support'
      ],
      gradient: 'from-gray-600 to-gray-700',
      buttonStyle: 'btn-secondary',
      popular: false
    },
    {
      name: 'Pro',
      icon: Zap,
      price: '$19.99',
      period: '/month',
      description: 'Most popular for serious fitness enthusiasts',
      features: [
        'All Basic features',
        'AI-powered workout plans',
        'Live training sessions',
        'Personal trainer chat',
        'Advanced analytics',
        'Nutrition guidance',
        'Wearable device sync'
      ],
      gradient: 'from-primary-500 to-secondary-500',
      buttonStyle: 'btn-primary',
      popular: true
    },
    {
      name: 'Elite',
      icon: Crown,
      price: '$39.99',
      period: '/month',
      description: 'Ultimate fitness experience',
      features: [
        'All Pro features',
        '1:1 Personal training sessions',
        'Custom meal planning',
        'Priority support',
        'Exclusive masterclasses',
        'Fitness gear discounts',
        'VIP community access'
      ],
      gradient: 'from-accent-500 to-error-500',
      buttonStyle: 'btn-primary',
      popular: false
    }
  ];

  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-dark-800 via-dark-900 to-dark-800" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Choose Your{' '}
            <span className="bg-gradient-to-r from-primary-400 to-secondary-400 bg-clip-text text-transparent">
              Fitness Plan
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Select the perfect plan to match your fitness goals and unlock your full potential.
          </p>
        </motion.div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => {
            const Icon = plan.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className={`relative bg-gradient-to-br from-dark-800/50 to-dark-900/50 backdrop-blur-md border ${
                  plan.popular ? 'border-primary-500/50' : 'border-white/10'
                } rounded-2xl p-8 transition-all duration-300 hover:shadow-2xl ${
                  plan.popular ? 'hover:shadow-primary-500/20' : ''
                }`}
              >
                {/* Popular Badge */}
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-gradient-to-r from-primary-500 to-secondary-500 text-white px-6 py-2 rounded-full text-sm font-semibold">
                      Most Popular
                    </div>
                  </div>
                )}

                {/* Plan Header */}
                <div className="text-center mb-8">
                  <div className={`w-16 h-16 bg-gradient-to-r ${plan.gradient} rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <Icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                  <p className="text-gray-400 mb-4">{plan.description}</p>
                  <div className="flex items-baseline justify-center">
                    <span className="text-4xl font-bold text-white">{plan.price}</span>
                    <span className="text-gray-400 ml-1">{plan.period}</span>
                  </div>
                </div>

                {/* Features */}
                <div className="mb-8">
                  <ul className="space-y-3">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center space-x-3">
                        <div className="bg-success-500/20 rounded-full p-1">
                          <Check className="h-3 w-3 text-success-400" />
                        </div>
                        <span className="text-gray-300 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* CTA Button */}
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`w-full ${plan.buttonStyle} ${
                    plan.popular ? 'shadow-lg shadow-primary-500/25' : ''
                  }`}
                >
                  {plan.popular ? 'Start Free Trial' : 'Get Started'}
                </motion.button>
              </motion.div>
            );
          })}
        </div>

        {/* Money Back Guarantee */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <div className="bg-gradient-to-r from-success-500/20 to-primary-500/20 backdrop-blur-md border border-white/10 rounded-xl p-6 max-w-2xl mx-auto">
            <h3 className="text-xl font-semibold text-white mb-2">30-Day Money-Back Guarantee</h3>
            <p className="text-gray-300">
              Try FitPro risk-free. If you're not completely satisfied within 30 days, 
              we'll refund your money, no questions asked.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Pricing;