import React from 'react';
import { motion } from 'framer-motion';
import { 
  Brain, 
  Video, 
  Users, 
  TrendingUp, 
  ShoppingCart, 
  Calendar,
  Smartphone,
  Trophy
} from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: Brain,
      title: 'AI Fitness Coach',
      description: 'Personalized workout plans powered by advanced AI that adapts to your progress and goals.',
      gradient: 'from-primary-500 to-secondary-500'
    },
    {
      icon: Video,
      title: 'Live Training Sessions',
      description: 'Join real-time workout sessions with certified trainers from anywhere in the world.',
      gradient: 'from-secondary-500 to-accent-500'
    },
    {
      icon: TrendingUp,
      title: 'Progress Tracking',
      description: 'Comprehensive analytics and insights to monitor your fitness journey and achievements.',
      gradient: 'from-accent-500 to-error-500'
    },
    {
      icon: Users,
      title: 'Community Hub',
      description: 'Connect with like-minded fitness enthusiasts, share achievements, and find motivation.',
      gradient: 'from-error-500 to-primary-500'
    },
    {
      icon: ShoppingCart,
      title: 'Fitness Marketplace',
      description: 'Shop for premium gym equipment, supplements, and nutrition plans all in one place.',
      gradient: 'from-primary-500 to-secondary-500'
    },
    {
      icon: Calendar,
      title: 'Personal Training',
      description: 'Book one-on-one sessions with expert trainers tailored to your specific needs.',
      gradient: 'from-secondary-500 to-accent-500'
    },
    {
      icon: Smartphone,
      title: 'Wearable Integration',
      description: 'Sync with your favorite fitness devices for real-time health monitoring and tracking.',
      gradient: 'from-accent-500 to-error-500'
    },
    {
      icon: Trophy,
      title: 'Gamification',
      description: 'Earn points, unlock achievements, and compete on leaderboards to stay motivated.',
      gradient: 'from-error-500 to-primary-500'
    },
  ];

  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-dark-900 via-dark-800 to-dark-900" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Revolutionary{' '}
            <span className="bg-gradient-to-r from-primary-400 to-secondary-400 bg-clip-text text-transparent">
              Features
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Discover the cutting-edge technology and comprehensive tools that make FitPro 
            the ultimate fitness platform for achieving your goals.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="feature-card group"
              >
                <div className={`w-12 h-12 bg-gradient-to-r ${feature.gradient} rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-400 leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Feature Showcase */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-24 bg-gradient-to-r from-primary-500/10 to-secondary-500/10 backdrop-blur-md border border-white/10 rounded-2xl p-8 md:p-12"
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-bold text-white mb-6">
                Experience the Future of Fitness
              </h3>
              <p className="text-gray-300 text-lg mb-8 leading-relaxed">
                Our AI-powered platform learns your preferences, tracks your progress, 
                and adapts to provide the most effective workout experience tailored just for you.
              </p>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-primary-400 rounded-full" />
                  <span className="text-gray-300">Real-time form correction with AI analysis</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-secondary-400 rounded-full" />
                  <span className="text-gray-300">Personalized nutrition recommendations</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-accent-400 rounded-full" />
                  <span className="text-gray-300">Social challenges and community support</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-primary-500/20 to-secondary-500/20 backdrop-blur-md border border-white/10 rounded-xl p-6 transform rotate-3 hover:rotate-0 transition-transform duration-300">
                <div className="bg-dark-800 rounded-lg p-4 mb-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <div className="w-3 h-3 bg-success-400 rounded-full" />
                    <span className="text-sm text-gray-300">AI Coach Active</span>
                  </div>
                  <div className="text-lg font-semibold text-white">
                    Today's Recommendation
                  </div>
                  <div className="text-gray-400 text-sm">
                    Upper Body Strength Training
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300 text-sm">Progress</span>
                    <span className="text-primary-400 text-sm font-semibold">78%</span>
                  </div>
                  <div className="w-full bg-dark-700 rounded-full h-2">
                    <div className="bg-gradient-to-r from-primary-500 to-secondary-500 h-2 rounded-full w-3/4" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Features;