import React from 'react';
import { motion } from 'framer-motion';
import { 
  Calendar, 
  Users, 
  DollarSign, 
  TrendingUp, 
  Video, 
  MessageSquare,
  Star,
  Clock,
  Plus,
  Edit,
  Eye
} from 'lucide-react';

const TrainerPortal = () => {
  const stats = [
    { icon: Users, value: '156', label: 'Active Clients', change: '+12%' },
    { icon: Calendar, value: '23', label: 'Sessions Today', change: '+5%' },
    { icon: DollarSign, value: '$2,840', label: 'Monthly Earnings', change: '+18%' },
    { icon: Star, value: '4.9', label: 'Average Rating', change: '+0.2%' },
  ];

  const upcomingSessions = [
    {
      client: 'Sarah Johnson',
      time: '10:00 AM',
      type: 'Personal Training',
      status: 'confirmed',
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg'
    },
    {
      client: 'Mike Chen',
      time: '2:30 PM',
      type: 'Nutrition Consultation',
      status: 'pending',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg'
    },
    {
      client: 'Emma Davis',
      time: '4:00 PM',
      type: 'Yoga Session',
      status: 'confirmed',
      avatar: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg'
    },
  ];

  const myWorkouts = [
    {
      title: 'HIIT Cardio Blast',
      duration: '30 min',
      views: '1.2K',
      rating: 4.8,
      image: 'https://images.pexels.com/photos/3757942/pexels-photo-3757942.jpeg'
    },
    {
      title: 'Strength Training Basics',
      duration: '45 min',
      views: '890',
      rating: 4.9,
      image: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg'
    },
    {
      title: 'Morning Yoga Flow',
      duration: '25 min',
      views: '2.1K',
      rating: 4.7,
      image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg'
    },
  ];

  return (
    <div className="min-h-screen pt-20 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-white mb-2">Trainer Dashboard 🏋️‍♂️</h1>
          <p className="text-gray-400">Manage your sessions, clients, and workout content</p>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
        >
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                whileHover={{ scale: 1.05 }}
                className="bg-gradient-to-br from-dark-800/50 to-dark-900/50 backdrop-blur-md border border-white/10 rounded-xl p-6"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-gradient-to-r from-primary-500 to-secondary-500 p-2 rounded-lg">
                    <Icon className="h-5 w-5 text-white" />
                  </div>
                  <span className="text-success-400 text-sm font-medium">{stat.change}</span>
                </div>
                <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-gray-400 text-sm">{stat.label}</div>
              </motion.div>
            );
          })}
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2 space-y-6"
          >
            {/* Today's Schedule */}
            <div className="bg-gradient-to-br from-dark-800/50 to-dark-900/50 backdrop-blur-md border border-white/10 rounded-xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-white">Today's Schedule</h2>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-gradient-to-r from-primary-500 to-secondary-500 text-white px-4 py-2 rounded-lg font-medium flex items-center space-x-2"
                >
                  <Plus className="h-4 w-4" />
                  <span>Add Session</span>
                </motion.button>
              </div>
              <div className="space-y-4">
                {upcomingSessions.map((session, index) => (
                  <motion.div
                    key={index}
                    whileHover={{ scale: 1.02 }}
                    className="flex items-center space-x-4 p-4 bg-dark-800/50 rounded-lg border border-white/5 hover:border-primary-500/30 transition-all duration-300"
                  >
                    <img
                      src={session.avatar}
                      alt={session.client}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold text-white">{session.client}</h3>
                      <p className="text-gray-400 text-sm">{session.type}</p>
                      <div className="flex items-center space-x-2 mt-1">
                        <Clock className="h-3 w-3 text-gray-500" />
                        <span className="text-gray-500 text-xs">{session.time}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        session.status === 'confirmed' 
                          ? 'bg-success-500/20 text-success-400'
                          : 'bg-warning-500/20 text-warning-400'
                      }`}>
                        {session.status}
                      </span>
                      <div className="flex space-x-1">
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className="p-2 text-gray-400 hover:text-white transition-colors"
                        >
                          <Video className="h-4 w-4" />
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className="p-2 text-gray-400 hover:text-white transition-colors"
                        >
                          <MessageSquare className="h-4 w-4" />
                        </motion.button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* My Workouts */}
            <div className="bg-gradient-to-br from-dark-800/50 to-dark-900/50 backdrop-blur-md border border-white/10 rounded-xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-white">My Workout Videos</h2>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-gradient-to-r from-primary-500 to-secondary-500 text-white px-4 py-2 rounded-lg font-medium flex items-center space-x-2"
                >
                  <Plus className="h-4 w-4" />
                  <span>Upload Video</span>
                </motion.button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {myWorkouts.map((workout, index) => (
                  <motion.div
                    key={index}
                    whileHover={{ scale: 1.02 }}
                    className="bg-dark-800/50 rounded-lg overflow-hidden border border-white/5 hover:border-primary-500/30 transition-all duration-300"
                  >
                    <div className="relative">
                      <img
                        src={workout.image}
                        alt={workout.title}
                        className="w-full h-32 object-cover"
                      />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-300">
                        <div className="flex space-x-2">
                          <motion.button
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            className="bg-white/20 backdrop-blur-md p-2 rounded-full"
                          >
                            <Eye className="h-4 w-4 text-white" />
                          </motion.button>
                          <motion.button
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            className="bg-white/20 backdrop-blur-md p-2 rounded-full"
                          >
                            <Edit className="h-4 w-4 text-white" />
                          </motion.button>
                        </div>
                      </div>
                    </div>
                    <div className="p-4">
                      <h3 className="font-semibold text-white mb-2">{workout.title}</h3>
                      <div className="flex items-center justify-between text-sm text-gray-400">
                        <span>{workout.duration}</span>
                        <div className="flex items-center space-x-2">
                          <Eye className="h-3 w-3" />
                          <span>{workout.views}</span>
                          <Star className="h-3 w-3 text-yellow-400" />
                          <span>{workout.rating}</span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-6"
          >
            {/* Performance Chart */}
            <div className="bg-gradient-to-br from-dark-800/50 to-dark-900/50 backdrop-blur-md border border-white/10 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4">This Week's Performance</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-400 text-sm">Sessions Completed</span>
                    <span className="text-white font-semibold">42/45</span>
                  </div>
                  <div className="w-full bg-dark-700 rounded-full h-2">
                    <div className="bg-gradient-to-r from-primary-500 to-secondary-500 h-2 rounded-full" style={{ width: '93%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-400 text-sm">Client Satisfaction</span>
                    <span className="text-white font-semibold">98%</span>
                  </div>
                  <div className="w-full bg-dark-700 rounded-full h-2">
                    <div className="bg-gradient-to-r from-success-500 to-primary-500 h-2 rounded-full" style={{ width: '98%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-400 text-sm">Response Time</span>
                    <span className="text-white font-semibold">2.3 min</span>
                  </div>
                  <div className="w-full bg-dark-700 rounded-full h-2">
                    <div className="bg-gradient-to-r from-secondary-500 to-accent-500 h-2 rounded-full" style={{ width: '85%' }} />
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-gradient-to-br from-dark-800/50 to-dark-900/50 backdrop-blur-md border border-white/10 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full bg-gradient-to-r from-primary-500 to-secondary-500 text-white py-3 px-4 rounded-lg font-medium transition-all duration-300 hover:shadow-lg"
                >
                  Start Live Session
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full bg-white/10 backdrop-blur-md border border-white/20 text-white py-3 px-4 rounded-lg font-medium transition-all duration-300 hover:bg-white/20"
                >
                  View Messages
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full bg-white/10 backdrop-blur-md border border-white/20 text-white py-3 px-4 rounded-lg font-medium transition-all duration-300 hover:bg-white/20"
                >
                  Analytics
                </motion.button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default TrainerPortal;