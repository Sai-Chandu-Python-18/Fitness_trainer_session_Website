import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import Dashboard from './components/Dashboard';
import TrainerPortal from './components/TrainerPortal';
import Pricing from './components/Pricing';
import Community from './components/Community';
import Footer from './components/Footer';

function App() {
  const [currentView, setCurrentView] = useState<'home' | 'dashboard' | 'trainer'>('home');

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard />;
      case 'trainer':
        return <TrainerPortal />;
      default:
        return (
          <>
            <Hero onGetStarted={() => setCurrentView('dashboard')} />
            <Features />
            <Pricing />
            <Community />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-dark-900">
      <Navbar currentView={currentView} setCurrentView={setCurrentView} />
      <motion.div
        key={currentView}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {renderContent()}
      </motion.div>
      {currentView === 'home' && <Footer />}
    </div>
  );
}

export default App;